# Message Board

For this assignment, you will create a simple single page message board that allows users to create messages, and comment on existing messages. Remember to put some time into planning out your database to play to Mongo's strengths. Include validations so empty fields are not permitted. Follow the wireframe below:
